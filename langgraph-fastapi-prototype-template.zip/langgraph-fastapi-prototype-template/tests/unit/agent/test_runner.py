import pytest
from langgraph.checkpoint.memory import InMemorySaver

from my_agent_service.agent.graph import build_graph
from my_agent_service.agent.runner import AgentRunner
from my_agent_service.agent.schemas import AgentInput


@pytest.mark.asyncio
async def test_runner_echo_mode_returns_reply():
    graph = build_graph(checkpointer=InMemorySaver(), llm=None)
    runner = AgentRunner(graph=graph)

    output = await runner.ainvoke(AgentInput(user_message="ping"), thread_id="test-thread")

    assert "ping" in output.reply
