from fastapi import FastAPI
from fastapi.testclient import TestClient
from langgraph.checkpoint.memory import InMemorySaver

from my_agent_service.agent.graph import build_graph
from my_agent_service.agent.runner import AgentRunner
from my_agent_service.api.deps import get_runner
from my_agent_service.api.v1.router import api_router


def test_chat_invoke_endpoint():
    app = FastAPI()
    app.include_router(api_router)
    runner = AgentRunner(graph=build_graph(checkpointer=InMemorySaver(), llm=None))
    app.dependency_overrides[get_runner] = lambda: runner

    with TestClient(app) as client:
        res = client.post("/v1/chat/invoke", json={"message": "hello"})

    assert res.status_code == 200
    assert "hello" in res.json()["reply"]
