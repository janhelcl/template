def main() -> None:
    print("Run the API with: uvicorn my_agent_service.api.main:app --reload")
