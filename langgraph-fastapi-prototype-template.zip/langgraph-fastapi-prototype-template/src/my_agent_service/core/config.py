from functools import lru_cache
from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "langgraph-fastapi-prototype"
    environment: str = "dev"
    log_level: str = "INFO"

    llm_provider: str = "echo"  # echo | openai | anthropic
    llm_model: str = "gpt-4o-mini"
    openai_api_key: SecretStr | None = None
    anthropic_api_key: SecretStr | None = None
    llm_timeout_seconds: float = 60
    llm_max_retries: int = 0

    postgres_dsn: str = "postgresql://postgres:postgres@localhost:5432/agent"
    postgres_pool_min_size: int = Field(default=2, ge=1)
    postgres_pool_max_size: int = Field(default=20, ge=1)

    cors_origins: str = "http://localhost:5173,http://localhost:3000"

    enable_otel: bool = False
    otel_exporter_otlp_endpoint: str | None = None

    @property
    def cors_origin_list(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
