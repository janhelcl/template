from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=10_000)
    thread_id: str | None = None
    user_id: str = "prototype-user"
    tenant_id: str = "prototype-tenant"


class ChatResponse(BaseModel):
    thread_id: str
    reply: str
    tool_calls_made: int = 0


class RunCreated(BaseModel):
    thread_id: str
    status: str = "running"


class RunStatus(BaseModel):
    thread_id: str
    status: str
    result: str | None = None
