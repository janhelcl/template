from contextlib import asynccontextmanager

import structlog
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from prometheus_fastapi_instrumentator import Instrumentator

from my_agent_service.agent.graph import build_graph
from my_agent_service.agent.llm import build_llm
from my_agent_service.agent.runner import AgentRunner
from my_agent_service.api.v1.router import api_router
from my_agent_service.core.config import get_settings
from my_agent_service.core.logging import configure_logging
from my_agent_service.core.observability import init_observability
from my_agent_service.services.checkpointing import build_checkpointer, build_postgres_pool

log = structlog.get_logger()


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    configure_logging(settings.log_level)

    pool = build_postgres_pool(settings)
    await pool.open(wait=True, timeout=10)
    checkpointer = await build_checkpointer(pool)
    llm = build_llm(settings)
    graph = build_graph(checkpointer=checkpointer, llm=llm)

    app.state.pool = pool
    app.state.runner = AgentRunner(graph=graph)
    log.info("app_started", llm_provider=settings.llm_provider)
    try:
        yield
    finally:
        log.info("app_stopping")
        await pool.close()


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(title=settings.app_name, lifespan=lifespan)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origin_list,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.include_router(api_router)
    Instrumentator().instrument(app).expose(app, endpoint="/metrics")
    init_observability(app, enabled=settings.enable_otel)
    return app


app = create_app()
