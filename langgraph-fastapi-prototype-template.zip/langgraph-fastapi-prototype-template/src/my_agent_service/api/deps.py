from fastapi import Request

from my_agent_service.agent.runner import AgentRunner


def get_runner(request: Request) -> AgentRunner:
    return request.app.state.runner
