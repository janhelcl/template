from fastapi import APIRouter, Request, Response

router = APIRouter(tags=["health"])


@router.get("/health")
async def health() -> dict:
    return {"status": "ok"}


@router.get("/ready")
async def ready(request: Request, response: Response) -> dict:
    pool = getattr(request.app.state, "pool", None)
    if pool is None:
        response.status_code = 503
        return {"status": "not_ready", "checks": {"postgres": "missing"}}
    try:
        async with pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute("SELECT 1")
                await cur.fetchone()
        return {"status": "ready", "checks": {"postgres": "ok"}}
    except Exception:
        response.status_code = 503
        return {"status": "not_ready", "checks": {"postgres": "fail"}}
