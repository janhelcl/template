import json
from uuid import uuid4

from fastapi import APIRouter, Depends, Request
from fastapi.responses import StreamingResponse

from my_agent_service.agent.runner import AgentRunner
from my_agent_service.agent.schemas import AgentInput
from my_agent_service.api.deps import get_runner
from my_agent_service.api.schemas import ChatRequest, ChatResponse

router = APIRouter(prefix="/chat", tags=["chat"])


def _thread_id(body: ChatRequest) -> str:
    return body.thread_id or str(uuid4())


def _agent_input(body: ChatRequest) -> AgentInput:
    return AgentInput(user_message=body.message, user_id=body.user_id, tenant_id=body.tenant_id)


def _sse(event: str, data: dict) -> str:
    return f"event: {event}\ndata: {json.dumps(data, default=str)}\n\n"


@router.post("/invoke", response_model=ChatResponse)
async def invoke_chat(body: ChatRequest, runner: AgentRunner = Depends(get_runner)) -> ChatResponse:
    thread_id = _thread_id(body)
    output = await runner.ainvoke(_agent_input(body), thread_id=thread_id)
    return ChatResponse(thread_id=thread_id, **output.model_dump())


@router.post("/stream")
async def stream_chat(
    body: ChatRequest,
    request: Request,
    runner: AgentRunner = Depends(get_runner),
) -> StreamingResponse:
    thread_id = _thread_id(body)
    payload = _agent_input(body)

    async def gen():
        try:
            yield _sse("thread", {"thread_id": thread_id})
            async for ev in runner.astream_events(payload, thread_id=thread_id):
                if await request.is_disconnected():
                    break

                kind = ev.get("event")
                if kind == "on_chat_model_stream":
                    chunk = ev.get("data", {}).get("chunk")
                    text = getattr(chunk, "content", None)
                    if text:
                        yield _sse("token", {"text": text})
                elif kind == "on_chat_model_end":
                    output = ev.get("data", {}).get("output")
                    text = getattr(output, "content", None)
                    if text:
                        yield _sse("message", {"text": text})
                elif kind == "on_tool_start":
                    yield _sse("tool_start", {"name": ev.get("name"), "input": ev.get("data", {}).get("input")})
                elif kind == "on_tool_end":
                    yield _sse("tool_end", {"name": ev.get("name")})
            yield _sse("done", {})
        except Exception as exc:  # keep stream clients informed during prototypes
            yield _sse("error", {"detail": str(exc)})

    return StreamingResponse(
        gen(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
