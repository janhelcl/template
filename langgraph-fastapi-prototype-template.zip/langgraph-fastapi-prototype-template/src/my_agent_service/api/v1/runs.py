from uuid import uuid4

from fastapi import APIRouter, BackgroundTasks, Depends

from my_agent_service.agent.runner import AgentRunner
from my_agent_service.agent.schemas import AgentInput
from my_agent_service.api.deps import get_runner
from my_agent_service.api.schemas import ChatRequest, RunCreated, RunStatus

router = APIRouter(prefix="/runs", tags=["runs"])


async def _run_agent(runner: AgentRunner, payload: AgentInput, thread_id: str) -> None:
    await runner.ainvoke(payload, thread_id=thread_id)


@router.post("", status_code=202, response_model=RunCreated)
async def create_run(
    body: ChatRequest,
    background: BackgroundTasks,
    runner: AgentRunner = Depends(get_runner),
) -> RunCreated:
    thread_id = body.thread_id or str(uuid4())
    payload = AgentInput(user_message=body.message, user_id=body.user_id, tenant_id=body.tenant_id)
    background.add_task(_run_agent, runner, payload, thread_id)
    return RunCreated(thread_id=thread_id)


@router.get("/{thread_id}", response_model=RunStatus)
async def get_run(thread_id: str, runner: AgentRunner = Depends(get_runner)) -> RunStatus:
    snapshot = await runner.aget_state(thread_id=thread_id)
    if getattr(snapshot, "next", None):
        return RunStatus(thread_id=thread_id, status="running")
    messages = getattr(snapshot, "values", {}).get("messages", [])
    result = str(getattr(messages[-1], "content", "")) if messages else None
    return RunStatus(thread_id=thread_id, status="done" if result else "unknown", result=result)
