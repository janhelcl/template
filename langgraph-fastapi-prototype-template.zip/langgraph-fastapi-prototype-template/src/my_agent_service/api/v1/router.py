from fastapi import APIRouter

from my_agent_service.api.v1 import chat, health, runs

api_router = APIRouter(prefix="/v1")
api_router.include_router(chat.router)
api_router.include_router(runs.router)
api_router.include_router(health.router)
