from pydantic import BaseModel, Field
from langchain_core.tools import tool


class LookupCustomerArgs(BaseModel):
    customer_id: str = Field(..., description="Synthetic customer identifier")


@tool(args_schema=LookupCustomerArgs)
def lookup_customer(customer_id: str) -> dict:
    """Lookup a synthetic customer record for prototypes."""
    return {
        "customer_id": customer_id,
        "segment": "prototype",
        "status": "active",
        "open_tickets": 1,
    }
