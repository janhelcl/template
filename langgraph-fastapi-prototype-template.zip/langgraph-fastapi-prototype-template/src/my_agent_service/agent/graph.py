from langchain_core.language_models.chat_models import BaseChatModel
from langgraph.graph import END, START, StateGraph

from my_agent_service.agent.nodes.assistant import make_assistant_node
from my_agent_service.agent.state import AgentState


def build_graph(*, checkpointer=None, llm: BaseChatModel | None = None):
    graph = StateGraph(AgentState)
    graph.add_node("assistant", make_assistant_node(llm))
    graph.add_edge(START, "assistant")
    graph.add_edge("assistant", END)
    return graph.compile(checkpointer=checkpointer)
