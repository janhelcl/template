from langchain_core.messages import AIMessage, HumanMessage
from pydantic import BaseModel, Field


class AgentInput(BaseModel):
    user_message: str = Field(..., min_length=1, max_length=10_000)
    user_id: str = "prototype-user"
    tenant_id: str = "prototype-tenant"

    def to_state(self) -> dict:
        return {
            "messages": [HumanMessage(content=self.user_message)],
            "user_id": self.user_id,
            "tenant_id": self.tenant_id,
        }


class AgentOutput(BaseModel):
    reply: str
    tool_calls_made: int = 0

    @classmethod
    def from_state(cls, state: dict) -> "AgentOutput":
        messages = state.get("messages", [])
        last = messages[-1] if messages else AIMessage(content="")
        return cls(
            reply=str(getattr(last, "content", "")),
            tool_calls_made=sum(1 for msg in messages if getattr(msg, "tool_calls", None)),
        )
