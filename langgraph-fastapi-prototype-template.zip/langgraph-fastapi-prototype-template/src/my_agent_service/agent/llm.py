from langchain_anthropic import ChatAnthropic
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_openai import ChatOpenAI

from my_agent_service.core.config import Settings


def build_llm(settings: Settings) -> BaseChatModel | None:
    """Return None for echo mode so prototypes run without API keys."""
    provider = settings.llm_provider.lower()
    if provider == "echo":
        return None
    if provider == "openai":
        return ChatOpenAI(
            model=settings.llm_model,
            api_key=settings.openai_api_key.get_secret_value() if settings.openai_api_key else None,
            timeout=settings.llm_timeout_seconds,
            max_retries=settings.llm_max_retries,
        )
    if provider == "anthropic":
        return ChatAnthropic(
            model=settings.llm_model,
            api_key=settings.anthropic_api_key.get_secret_value() if settings.anthropic_api_key else None,
            timeout=settings.llm_timeout_seconds,
            max_retries=settings.llm_max_retries,
        )
    raise ValueError(f"Unsupported LLM_PROVIDER={settings.llm_provider!r}")
