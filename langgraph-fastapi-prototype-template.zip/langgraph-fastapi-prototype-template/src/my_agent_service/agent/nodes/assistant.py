from pathlib import Path

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, SystemMessage

from my_agent_service.agent.state import AgentState

PROMPT = (Path(__file__).parents[1] / "prompts" / "system.md").read_text(encoding="utf-8")


def make_assistant_node(llm: BaseChatModel | None):
    """Factory node. Tests can inject fake models; local dev can use echo mode."""

    async def assistant_node(state: AgentState) -> dict:
        messages = state.get("messages", [])
        if llm is None:
            user_text = getattr(messages[-1], "content", "") if messages else ""
            return {"messages": [AIMessage(content=f"Echo prototype response: {user_text}")]}

        response = await llm.ainvoke([SystemMessage(content=PROMPT), *messages])
        return {"messages": [response]}

    return assistant_node
