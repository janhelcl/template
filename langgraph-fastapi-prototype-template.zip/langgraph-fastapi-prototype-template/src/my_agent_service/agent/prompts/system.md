You are a concise prototype assistant.

When integrating a real prototype, replace this prompt and add domain-specific tools in `agent/tools/`.
