from dataclasses import dataclass
from typing import AsyncIterator

from langgraph.graph.state import CompiledStateGraph

from my_agent_service.agent.schemas import AgentInput, AgentOutput


@dataclass(frozen=True)
class AgentRunner:
    graph: CompiledStateGraph

    async def ainvoke(self, payload: AgentInput, *, thread_id: str) -> AgentOutput:
        config = {"configurable": {"thread_id": thread_id}}
        result = await self.graph.ainvoke(payload.to_state(), config=config)
        return AgentOutput.from_state(result)

    async def astream_events(self, payload: AgentInput, *, thread_id: str) -> AsyncIterator[dict]:
        config = {"configurable": {"thread_id": thread_id}}
        async for event in self.graph.astream_events(payload.to_state(), config=config, version="v2"):
            yield event

    async def aget_state(self, *, thread_id: str):
        config = {"configurable": {"thread_id": thread_id}}
        return await self.graph.aget_state(config)
