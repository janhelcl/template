from typing import Annotated, TypedDict

from langchain_core.messages import AnyMessage
from langgraph.graph.message import add_messages


class AgentState(TypedDict, total=False):
    """Internal graph state. Keep it flexible; validate only at boundaries."""

    messages: Annotated[list[AnyMessage], add_messages]
    user_id: str
    tenant_id: str
    summary: str | None
    retrieved_docs: list[dict]
