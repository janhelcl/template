# LangGraph + FastAPI Prototype Template

A self-hosted starter repo for quickly building LangGraph prototypes behind a simple FastAPI backend, without adopting LangGraph Platform or a queue-first architecture.

The default app is deliberately boring: one compiled graph, one `AgentRunner`, Postgres checkpointing, an invoke endpoint, an SSE stream endpoint, background-run status endpoints, and a placeholder frontend. The point is to let engineers focus on agent logic.

## What this template is for

Use this when you need to prototype things like:

- customer assistants with multiple tool/system integrations,
- session-based chat with checkpointing,
- document processing flows,
- email prioritization/routing,
- internal research assistants,
- synthetic-data demos before real-system integration exists.

It is **not** a clone of LangGraph Platform. There is no auth, no tenant admin UI, no distributed worker runtime, no multi-agent registry, and no production-grade frontend.

## Shape of the repo

```text
src/my_agent_service/
├── agent/                   # pure Python, no FastAPI imports
│   ├── state.py             # internal TypedDict state + reducers
│   ├── schemas.py           # Pydantic agent input/output contract
│   ├── nodes/               # node factories
│   ├── tools/               # tool definitions and Pydantic args schemas
│   ├── prompts/             # markdown prompts
│   ├── llm.py               # app-scoped LLM factory
│   ├── graph.py             # build_graph(...)
│   └── runner.py            # AgentRunner facade
├── api/                     # HTTP translation only
│   ├── main.py              # FastAPI app + lifespan
│   ├── deps.py              # request dependencies
│   ├── schemas.py           # HTTP DTOs
│   └── v1/                  # routes
├── services/                # checkpointer / external service setup
└── core/                    # config, logging, observability
frontend/                    # intentionally replaceable UI placeholder
```

## Design rules

1. `agent/` knows nothing about HTTP.
2. FastAPI imports `AgentRunner`, not graph internals.
3. State is `TypedDict`; boundaries are Pydantic.
4. Nodes are factories that close over dependencies.
5. Everything is async: `ainvoke`, `astream_events(version="v2")`, async DB/checkpointer.
6. Postgres pool and checkpointer are created once in FastAPI lifespan.
7. The default `LLM_PROVIDER=echo` mode runs without API keys.

## Quick start

### 1. Create env file

```bash
cp .env.example .env
```

The template defaults to `LLM_PROVIDER=echo`, so it runs without OpenAI/Anthropic keys.

### 2. Run with Docker Compose

```bash
docker compose up --build backend postgres
```

Check readiness:

```bash
curl http://localhost:8000/v1/ready
```

Invoke the agent:

```bash
curl -X POST http://localhost:8000/v1/chat/invoke \
  -H 'Content-Type: application/json' \
  -d '{"message":"hello"}'
```

Run the placeholder frontend too:

```bash
docker compose --profile frontend up --build
```

Open `http://localhost:5173`.

### 3. Local Python development

Using `uv`:

```bash
uv sync --extra dev
uv run uvicorn my_agent_service.api.main:app --reload
```

Start only Postgres if developing locally:

```bash
docker compose up postgres
```

## API surface

### `POST /v1/chat/invoke`

Blocking request/response call.

```json
{
  "message": "hello",
  "thread_id": null,
  "user_id": "prototype-user",
  "tenant_id": "prototype-tenant"
}
```

Returns:

```json
{
  "thread_id": "...",
  "reply": "...",
  "tool_calls_made": 0
}
```

Reuse the same `thread_id` to continue a session.

### `POST /v1/chat/stream`

SSE stream. Emits events such as:

- `thread`
- `token`
- `message`
- `tool_start`
- `tool_end`
- `done`
- `error`

Use this for runs where the user is waiting.

### `POST /v1/runs`

Starts a background run and returns immediately.

### `GET /v1/runs/{thread_id}`

Reads checkpoint state and returns a simple status/result.

## Switching to a real LLM

Edit `.env`:

```env
LLM_PROVIDER=openai
LLM_MODEL=gpt-4o-mini
OPENAI_API_KEY=...
LLM_MAX_RETRIES=0
```

or:

```env
LLM_PROVIDER=anthropic
LLM_MODEL=claude-3-5-sonnet-latest
ANTHROPIC_API_KEY=...
LLM_MAX_RETRIES=0
```

`LLM_MAX_RETRIES=0` is intentional. Add explicit retry/fallback logic around model calls when your prototype needs it; do not let SDK retries hide failures.

## Adding real agent logic

Most prototypes should touch only these files:

```text
agent/prompts/*.md
agent/tools/*.py
agent/nodes/*.py
agent/graph.py
agent/schemas.py
agent/state.py
```

### Add a tool

```python
from pydantic import BaseModel, Field
from langchain_core.tools import tool

class SearchTicketsArgs(BaseModel):
    customer_id: str = Field(..., description="Customer identifier")

@tool(args_schema=SearchTicketsArgs)
def search_tickets(customer_id: str) -> list[dict]:
    return [{"id": "T-1", "status": "open"}]
```

### Add a node

```python
def make_route_node(llm):
    async def route_node(state: AgentState) -> dict:
        # inspect state, call llm/tools, return partial state update
        return {"intent": "support"}
    return route_node
```

Wire it in `agent/graph.py`.

## Prototype data patterns

For customer-assistant prototypes, start with one of these:

1. **In-memory synthetic fixtures** in `agent/tools/` for very fast demos.
2. **Postgres synthetic tables** if you need realistic SQL/tooling behavior.
3. **Mocked external clients** under `services/` if you later want to swap in real APIs.

Keep tool return values small and explicit. Avoid returning raw database rows with dozens of unused columns.

## Checkpointing

The app uses `AsyncPostgresSaver` over a lifespan-owned `psycopg_pool.AsyncConnectionPool`.

Important defaults are in `services/checkpointing.py`:

```python
"autocommit": True,
"prepare_threshold": 0,
"row_factory": dict_row,
```

Do not remove them. They avoid common PostgresSaver failures with setup DDL, PgBouncer/prepared statements, and row access.

## Testing

Run:

```bash
uv run pytest
```

Testing strategy:

- unit-test nodes with fake dependencies,
- graph-test with `InMemorySaver`,
- API-test routes with a mocked or in-memory `AgentRunner`,
- keep real LLM calls out of normal CI.

## Observability

The skeleton includes:

- JSON `structlog`,
- Prometheus metrics at `/metrics`,
- optional OpenTelemetry instrumentation via `ENABLE_OTEL=true`.

For production-like prototypes, wire OTLP to Phoenix or Langfuse. Keep message-content capture disabled by default when using real user data.

## Frontend

`frontend/` is intentionally minimal. Replace it with whatever fits the prototype: Vite, Next.js, Streamlit, Retool, an internal portal, or no frontend at all.

## Cursor / coding-agent guidance

See:

- `AGENTS.md`
- `.cursor/rules/agent-template.mdc`

The most important rule for coding agents: **do not move business logic into FastAPI routes**. Keep the graph and tools testable as a pure Python library.
