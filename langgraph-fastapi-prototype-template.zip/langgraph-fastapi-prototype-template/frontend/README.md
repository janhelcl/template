# Frontend placeholder

This folder exists so prototypes can add a UI without changing the repo layout.

Default: tiny Vite + React app that calls `POST /v1/chat/invoke`.

Replace it freely with Next.js, plain React, Streamlit, or any other frontend.
