import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

function App() {
  const [message, setMessage] = useState('Hello from the frontend');
  const [reply, setReply] = useState('');
  const [threadId, setThreadId] = useState(null);

  async function send() {
    const res = await fetch('http://localhost:8000/v1/chat/invoke', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, thread_id: threadId }),
    });
    const data = await res.json();
    setThreadId(data.thread_id);
    setReply(data.reply);
  }

  return <main>
    <h1>Agent Prototype</h1>
    <p>This frontend is intentionally tiny. Replace it with your prototype UI.</p>
    <textarea value={message} onChange={e => setMessage(e.target.value)} />
    <button onClick={send}>Send</button>
    {threadId && <small>thread_id: {threadId}</small>}
    {reply && <pre>{reply}</pre>}
  </main>;
}

createRoot(document.getElementById('root')).render(<App />);
