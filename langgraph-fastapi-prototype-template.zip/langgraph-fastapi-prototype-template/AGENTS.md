# Instructions for coding agents

This repo is a prototype template. The engineer should spend almost all effort in `src/my_agent_service/agent/`.

## Hard boundaries

- Do not import FastAPI inside `agent/`.
- Do not expose `AgentState` through HTTP responses.
- Keep graph state as `TypedDict`; use Pydantic only at boundaries.
- Add new node logic as factories: `make_some_node(dependency) -> async node(state) -> dict`.
- FastAPI routes should import only `AgentRunner` and agent Pydantic schemas.
- Use `ainvoke` / `astream_events`; do not add sync `invoke` routes.
- Do not create Postgres pools or LLM clients per request.

## Where to implement things

- Customer assistant tools: `agent/tools/`, optionally backed by synthetic DB tables.
- Document processing nodes: `agent/nodes/`, with file parsing outside the HTTP route.
- Email prioritization/routing: add Pydantic tool schemas and a routing node.
- Prompt changes: markdown files under `agent/prompts/`.
- HTTP DTO changes: `api/schemas.py`.

## Testing expectations

- Unit test nodes with fake dependencies.
- Test the full graph with `InMemorySaver`.
- Keep real LLM calls out of normal CI.
